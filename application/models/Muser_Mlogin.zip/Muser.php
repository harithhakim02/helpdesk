<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Muser extends CI_Model {


    public function get_tiket(){
		$this->db->from('tiket t');
        $this->db->join('inventory i','i.id_inventory=i.id_inventory');
		$this->db->join('departemen d','d.id_departemen=i.id_departemen');
        $this->db->where('t.id_user', $this->session->userdata('id_user'));
        $this->db->select('t.*, d.nama_departemen AS DEPARTEMEN');
		return $this->db->get()->result();
	}
    public function get_profil($id=null)
    {
        $this->db->from('user u');
        $this->db->where('id_user',$id);
        $this->db->join('departemen d','d.id_departemen=d.id_departemen');
        $this->db->select('u.*, d.nama_departemen AS departemen');
        return $this->db->get();
        
    }
    public function generate()
    {
       $this->db->insert('T-'.time().rand(999,111)); 
        // $thn=date("Ym");
        // $this->db->select('RIGHT(tiket.id_tiket,4) as id',FALSE);
        // $this->db->order_by('id','DESC');
        // $this->db->limit(1);
        // $query=$this->db->get('tiket');

        // if ($query->num_rows()<>0) {
        //     $data=$query->row();
        //     $autonumber=intval($data->id)+1;
        // }else { 
        //     $autonumber=1;
        // }
        // $limit=str_pad($autonumber,4,"0",STR_PAD_LEFT);
        // $id= $thn.$limit;
        // return $id;
    }
    public function insert($data)
    {
        return $this->db->insert('tiket',$data);
    }
    public function update_profil($data,$id)
    {
        return $this->db->update('user', $data, ['id_user'=>$id]);
    }
}

